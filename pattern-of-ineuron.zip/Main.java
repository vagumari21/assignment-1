/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class Main
{
	public static void main(String[] args) {
		int n=12;
		for(int i=0;i<n;i++)
		{
		    for(int j=0;j<n;j++)
		    {
		        if(i==0 || j==(n-1)/2 || i==n-1)
		        {
		            System.out.print("*");
		        }
		        else
		        {
		            System.out.print(" ");
		        }
		    }
		    
		     System.out.print("  ");
		     
		     for(int j=0;j<n;j++)
		    {
		        if(i==j || j==0|| j==n-1 )
		        {
		            
		            System.out.print("*");
		        }
		        else
		        {
		            System.out.print(" ");
		        }
		    }
		   
		 
		 System.out.print(" ");
		 
		 
		     for(int j=0;j<n;j++)
		    {
		        
		        if(i==0 && j<=(3*n)/4 || j==0 || i==n-1 && j<=(3*n)/4 || i==(n-1)/2 && j<=(3*n)/4)
		        {
		            
		            System.out.print("*");
		        }
		        else
		        {
		            System.out.print(" ");
		        }
		        
		    }
		    
		    
		     for(int j=0;j<n;j++)
		    {
		        
		        if(j==0 || i==n-1 && j!=0 || j==n-1  )
		        {
		            
		            System.out.print("*");
		        }
		        else
		        {
		            System.out.print(" ");
		        }
		        
		    }
		    
		    
		    System.out.print("  ");
		    
		     for(int j=0;j<n;j++)
		    {
		        
		        if(i==0 && j<(3*n)/4|| j==0 || i==(n-1)/2 && j<(3*n)/4 || j==(3*n)/4 && i<(n-1)/2 || i==j  )
		        {
		            
		            System.out.print("*");
		        }
		        else
		        {
		            System.out.print(" ");
		        }
		        
		    }
		    System.out.print(" ");
		    
		     for(int j=0;j<n;j++)
		    {
		        
		        if(i==0 || j==0 || i==n-1 || j==n-1  )
		        {
		            
		            System.out.print("*");
		        }
		        else
		        {
		            System.out.print(" ");
		        }
		        
		    }
		    System.out.print(" ");
		    
		     
		     for(int j=0;j<n;j++)
		    {
		        if(i==j || j==0|| j==n-1 )
		        {
		            
		            System.out.print("*");
		        }
		        else
		        {
		            System.out.print(" ");
		        }
		    }
		 
		 System.out.println();
		    
		}
		
		 
	}	 
	
	  
}





